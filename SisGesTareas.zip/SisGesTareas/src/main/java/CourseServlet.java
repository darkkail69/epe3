import com.mycompany.controller.CourseController;
import com.mycompany.model.Course;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/CourseServlet")
public class CourseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CourseController courseController;

    // Inicializa el controlador de cursos
    @Override
    public void init() throws ServletException {
        courseController = new CourseController();
    }

    // Maneja las solicitudes POST para crear un nuevo curso
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");  // Obtiene el nombre del curso desde el formulario

        Course course = new Course();
        course.setName(name);

        // Crea un nuevo curso utilizando el controlador
        courseController.createCourse(course);

        // Redirige a la lista de cursos después de crear el curso
        response.sendRedirect("lista_cursos.jsp");
    }

    // Maneja las solicitudes GET, como listar cursos
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("list".equals(action)) {
            // Obtiene todos los cursos utilizando el controlador
            List<Course> courses = courseController.getAllCourses();

            // Envía la lista de cursos al JSP para mostrarlos
            request.setAttribute("courses", courses);
            request.getRequestDispatcher("lista_cursos.jsp").forward(request, response);
        }

        // Puedes agregar más acciones aquí, como editar o eliminar cursos
    }
}
