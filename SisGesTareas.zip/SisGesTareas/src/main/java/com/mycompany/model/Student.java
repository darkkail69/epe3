package com.mycompany.model;

import jakarta.persistence.*; // Importación corregida para Jakarta Persistence API
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Student implements Serializable {
    private static final long serialVersionUID = 1L; // ID de versión para serialización

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private int age;

    @ManyToMany(mappedBy = "students")
    private Set<Course> courses = new HashSet<>(); // Usar Set para evitar duplicados y asegurar integridad

    // Constructor
    public Student() {}

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Set<Course> getCourses() {
        return courses;
    }

    public void setCourses(Set<Course> courses) {
        this.courses = courses;
    }

    // En caso de que quieras añadir funcionalidad para manejar el email, añádelo aquí
    // Si no es necesario, puedes eliminar este método
    public void setEmail(String email) {
        throw new UnsupportedOperationException("Email field is not supported.");
    }
}
