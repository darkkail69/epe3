package com.mycompany.model;

import jakarta.persistence.*; // Cambiado de javax.persistence a jakarta.persistence
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Course implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @ManyToMany
    @JoinTable(name = "student_course", 
               joinColumns = @JoinColumn(name = "course_id"), 
               inverseJoinColumns = @JoinColumn(name = "student_id"))
    private Set<Student> students = new HashSet<>(); // Usar Set para evitar duplicados

    // Constructor
    public Course() {}

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Student> getStudents() {
        return students;
    }

    public void setStudents(Set<Student> students) {
        this.students = students;
    }
}
