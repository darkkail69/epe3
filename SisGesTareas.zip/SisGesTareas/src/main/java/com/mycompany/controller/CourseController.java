/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.controller;

/**
 *
 * @author Luis
 */

import com.mycompany.model.Course;
import com.mycompany.model.Student;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;
import java.io.IOException;
import java.util.List;

@WebServlet("/course")  // Define el servlet para manejar las solicitudes en esta ruta
public class CourseController extends HttpServlet {
    private final EntityManagerFactory emf;

    public CourseController() {
        this.emf = Persistence.createEntityManagerFactory("StudentManagementPU");
    }

    public void createCourse(Course course) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(course);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }

    public List<Course> getAllCourses() {
        try (EntityManager em = emf.createEntityManager()) {
            Query query = em.createQuery("SELECT c FROM Course c");
            return query.getResultList();
        }
    }

    public List<Student> getStudentsByCourse(Long courseId) {
        try (EntityManager em = emf.createEntityManager()) {
            Query query = em.createQuery("SELECT s FROM Student s JOIN s.courses c WHERE c.id = :courseId");
            query.setParameter("courseId", courseId);
            return query.getResultList();
        }
    }

    public List<Course> getCoursesByStudent(Long studentId) {
        try (EntityManager em = emf.createEntityManager()) {
            Query query = em.createQuery("SELECT c FROM Course c JOIN c.students s WHERE s.id = :studentId");
            query.setParameter("studentId", studentId);
            return query.getResultList();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String name = request.getParameter("name");

            Course course = new Course();
            course.setName(name);

            createCourse(course);  // Reutilizamos el método createCourse

            response.sendRedirect("lista_cursos.jsp"); // Redirige a la lista de cursos
        } catch (IOException e) {
            request.setAttribute("errorMessage", "Error al crear el curso.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}
