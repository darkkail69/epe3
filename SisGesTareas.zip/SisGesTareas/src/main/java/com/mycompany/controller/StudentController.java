package com.mycompany.controller;

import com.mycompany.model.Student;
import com.mycompany.model.Course;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;
import java.util.List;

public class StudentController {
    private final EntityManagerFactory emf;

    public StudentController() {
        this.emf = Persistence.createEntityManagerFactory("StudentManagementPU");
    }

    public void createStudent(Student student) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(student);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace(); // Imprime la traza del error para depuración
        } finally {
            em.close(); // Asegúrate de cerrar el EntityManager
        }
    }

    public void updateStudent(Student student) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(student); // Utiliza merge para actualizar el estudiante
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace(); // Imprime la traza del error para depuración
        } finally {
            em.close(); // Asegúrate de cerrar el EntityManager
        }
    }

    public List<Student> getAllStudents() {
        EntityManager em = emf.createEntityManager();
        try {
            Query query = em.createQuery("SELECT s FROM Student s");
            return query.getResultList();
        } finally {
            em.close(); // Asegúrate de cerrar el EntityManager
        }
    }

    public Student getStudentById(Long studentId) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.find(Student.class, studentId);
        } finally {
            em.close(); // Asegúrate de cerrar el EntityManager
        }
    }

    public void enrollStudentInCourse(Long studentId, Long courseId) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Student student = em.find(Student.class, studentId);
            Course course = em.find(Course.class, courseId);
            if (student != null && course != null) {
                student.getCourses().add(course);
                em.getTransaction().commit();
            } else {
                throw new IllegalArgumentException("Student or Course not found");
            }
        } catch (IllegalArgumentException e) {
            e.printStackTrace(); // Imprime la traza del error para depuración
        } finally {
            em.close(); // Asegúrate de cerrar el EntityManager
        }
    }
}
