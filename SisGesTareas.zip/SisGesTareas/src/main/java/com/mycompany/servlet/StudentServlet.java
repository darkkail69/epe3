package com.mycompany.servlet;

import com.mycompany.controller.StudentController;
import com.mycompany.model.Student;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private StudentController studentController;

    @Override
    public void init() throws ServletException {
        studentController = new StudentController();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id"); // Puede ser nulo si es un nuevo estudiante
        String name = request.getParameter("name");
        int age;

        try {
            age = Integer.parseInt(request.getParameter("age"));
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Invalid age format.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
            return;
        }

        if (id == null || id.isEmpty()) {
            // Crear nuevo estudiante
            Student student = new Student();
            student.setName(name);
            student.setAge(age);
            studentController.createStudent(student);
        } else {
            // Editar estudiante existente
            Long studentId;
            try {
                studentId = Long.parseLong(id);
            } catch (NumberFormatException e) {
                request.setAttribute("errorMessage", "Invalid student ID format.");
                request.getRequestDispatcher("error.jsp").forward(request, response);
                return;
            }

            Student student = studentController.getStudentById(studentId);
            if (student != null) {
                student.setName(name);
                student.setAge(age);
                studentController.updateStudent(student);
            } else {
                request.setAttribute("errorMessage", "Student not found.");
                request.getRequestDispatcher("error.jsp").forward(request, response);
                return;
            }
        }

        response.sendRedirect("lista_estudiantes.jsp");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("edit".equals(action)) {
            // Obtener los datos del estudiante para editar
            Long id;
            try {
                id = Long.parseLong(request.getParameter("id"));
            } catch (NumberFormatException e) {
                request.setAttribute("errorMessage", "Invalid student ID format.");
                request.getRequestDispatcher("error.jsp").forward(request, response);
                return;
            }

            Student student = studentController.getStudentById(id);
            request.setAttribute("student", student);
            request.getRequestDispatcher("formulario_estudiante.jsp").forward(request, response);
        } else if ("list".equals(action)) {
            // Listar todos los estudiantes
            List<Student> students = studentController.getAllStudents();
            request.setAttribute("students", students);
            request.getRequestDispatcher("lista_estudiantes.jsp").forward(request, response);
        }
    }
}
